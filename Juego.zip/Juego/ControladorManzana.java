import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ControladorManzana here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ControladorManzana extends Actor
{
    /**
     * Act - do whatever the ControladorManzana wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void aparecerManzanas(int x,int y)
    {
       for (int i = 0; i < 3; i++) {
            Mazana mazana = new Mazana();
            getWorld().addObject(mazana, x + Greenfoot.getRandomNumber(20) - 10, y + Greenfoot.getRandomNumber(20) - 10);
    }
}
}

