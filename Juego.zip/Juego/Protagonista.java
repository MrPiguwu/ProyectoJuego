import greenfoot.*;

public class Protagonista extends Actor
{
   

    public Protagonista()
    {
        
    }

    public void act()
    {
        if(Greenfoot.isKeyDown("Right")) {
            setRotation(0);
            move(2);
        }
        if(Greenfoot.isKeyDown("Down")) {
            setRotation(90);
            move(2);
        }
        if(Greenfoot.isKeyDown("Left")) {
            setRotation(180);
            move(2);
        }
        if(Greenfoot.isKeyDown("Up")) {
            setRotation(270);
            move(2);
        }

       
    }
}