import greenfoot.*;

public class Protagonista extends Actor
{
   

    public Protagonista()
    {
        
    }

    public void act()
    {
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 2); // Mover hacia arriba
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 2); // Mover hacia abajo
        }
        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 2, getY()); // Mover hacia la izquierda
        }
        if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 2, getY()); // Mover hacia la derecha
        }

       
    }
}