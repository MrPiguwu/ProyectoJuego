import greenfoot.*;  // Importar las clases Greenfoot

public class Fresa extends Actor {
    private long lastSpawnTime = 0;

    public void act() {
        // Verificar si es tiempo de hacer spawn de una nueva fresa
        if (System.currentTimeMillis() - lastSpawnTime >= 3000 && getWorld().getObjects(Fresa.class).isEmpty()) {
            spawnFresaRandom();
            lastSpawnTime = System.currentTimeMillis();
        }

        // Detectar colisión con el protagonista
        if (isTouching(Protagonista.class)) {
            Counter contadorManzanas = (Counter) getWorld().getObjects(Counter.class).get(0);
            contadorManzanas.add(1);
            getWorld().removeObject(this);  // Eliminar la fresa
        }
    }

    private void spawnFresaRandom() {
        int x = Greenfoot.getRandomNumber(700);
        int y = Greenfoot.getRandomNumber(650);
        getWorld().addObject(new Fresa(), x, y);
    }
}