import greenfoot.*;

public class MyWorld extends World {
    private long lastSpawnTime = 0;

    public MyWorld() {
        super(700, 650, 1); 
        prepare();
    }

    public void act() {
        // Verificar si es tiempo de hacer spawn de una nueva fresa
        if (System.currentTimeMillis() - lastSpawnTime >= 3000 && getObjects(Fresa.class).isEmpty()) {
            spawnFresaRandom();
            lastSpawnTime = System.currentTimeMillis();
            
        }
        if (System.currentTimeMillis() - lastSpawnTime >= 3000 && getObjects(Mazana.class).isEmpty()) {
            spawnMazanaRandom();
            lastSpawnTime = System.currentTimeMillis();
            
        }
        if (System.currentTimeMillis() - lastSpawnTime >= 3000 && getObjects(Naranja.class).isEmpty()) {
            spawnNaranjaRandom();
            lastSpawnTime = System.currentTimeMillis();
            
        }
    }

    private void spawnFresaRandom() {
        int x = Greenfoot.getRandomNumber(700);
        int y = Greenfoot.getRandomNumber(650);
        addObject(new Fresa(), x, y);
    }
      private void spawnMazanaRandom() {
        int x = Greenfoot.getRandomNumber(700);
        int y = Greenfoot.getRandomNumber(650);
        addObject(new Mazana(), x, y);
    }
      private void spawnNaranjaRandom() {
        int x = Greenfoot.getRandomNumber(700);
        int y = Greenfoot.getRandomNumber(650);
        addObject(new Naranja(), x, y);
    }

    private void prepare() {
        Protagonista protagonista = new Protagonista();
        addObject(protagonista, 77, 59);

        ArbolNaranja arbolNaranja = new ArbolNaranja();
        addObject(arbolNaranja, 80, 366);

        ArbolManzana arbolManzana = new ArbolManzana();
        addObject(arbolManzana, 560, 70);

        FresaVacia fresaVacia = new FresaVacia();
        addObject(fresaVacia, 588, 381);

        Fresas fresas = new Fresas();
        addObject(fresas, 588, 379);

        Counter counter = new Counter();
        addObject(counter, 58, 628);
    }
}