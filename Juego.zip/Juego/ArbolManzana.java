import greenfoot.*;

public class ArbolManzana extends Actor {
    private GreenfootImage arbolvacio = new GreenfootImage("Arbol.png");
    private GreenfootImage arbolmanzana = new GreenfootImage("ArbolManzana.png");
    private long tiempoCambio = 0;
    private boolean estaVacio = false;

    public void act() {
        Actor protagonista = getOneIntersectingObject(Protagonista.class);
        if (protagonista != null) {
            if (!estaVacio) {
                setImage(arbolvacio);
                tiempoCambio = System.currentTimeMillis() + 10000; // establecer el tiempo
                estaVacio = true;
                Greenfoot.playSound("SonidoManzanas.wav");
                Counter contadorManzanas = (Counter) getWorld().getObjects(Counter.class).get(0);
                contadorManzanas.add(3);
            }
        } else {
            if (estaVacio && System.currentTimeMillis() >= tiempoCambio) {
                setImage(arbolmanzana);
                estaVacio = false;
            }
        }
        
    }
}