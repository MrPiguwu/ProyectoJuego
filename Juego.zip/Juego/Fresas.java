import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Fresas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fresas extends Actor

{
    private GreenfootImage fresavacio = new GreenfootImage("FresaVacia.jpeg");
    private GreenfootImage fresas = new GreenfootImage("Fresas.jpeg");
    private long tiempoCambio = 0;
    private boolean estaVacio = false;
    /**
     * Act - do whatever the Fresas wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        Actor protagonista = getOneIntersectingObject(Protagonista.class);
        if (protagonista != null) {
            if (!estaVacio) {
                setImage(fresavacio);
                tiempoCambio = System.currentTimeMillis() + 10000; // establecer tiempo
                estaVacio = true;
                Greenfoot.playSound("SonidoFresas.wav");
                Counter contadorManzanas = (Counter) getWorld().getObjects(Counter.class).get(0);
                contadorManzanas.add(4);
            }
        } else {
            if (estaVacio && System.currentTimeMillis() >= tiempoCambio) {
                setImage(fresas);
                estaVacio = false;
            }
        }
    }
}
