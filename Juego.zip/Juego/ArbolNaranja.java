import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ArbolNaranja here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ArbolNaranja extends Actor
{
    private GreenfootImage arbolvacio = new GreenfootImage("Arbol.png");
    private GreenfootImage arbolnaranja = new GreenfootImage("ArbolNaranja.png");
    private long tiempoCambio = 0;
    private boolean estaVacio = false;
    /**
     * Act - do whatever the ArbolNaranja wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
       Actor protagonista = getOneIntersectingObject(Protagonista.class);
        if (protagonista != null) {
            if (!estaVacio) {
                setImage(arbolvacio);
                tiempoCambio = System.currentTimeMillis() + 10000; //establecer tiempo
                estaVacio = true;
                Greenfoot.playSound("SonidoNaranjas.wav");
                Counter contadorManzanas = (Counter) getWorld().getObjects(Counter.class).get(0);
                contadorManzanas.add(3);
            }
        } else {
            if (estaVacio && System.currentTimeMillis() >= tiempoCambio) {
                setImage(arbolnaranja);
                estaVacio = false;
            }
        }
    }
}
