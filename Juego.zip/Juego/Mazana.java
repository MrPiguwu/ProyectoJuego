import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mazana here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mazana extends Actor
{
   private long lastSpawnTime = 0;

    public void act() {
        // Verificar si es tiempo de hacer spawn de una nueva fresa
        if (System.currentTimeMillis() - lastSpawnTime >= 3000 && getWorld().getObjects(Mazana.class).isEmpty()) {
            spawnMazanaRandom();
            lastSpawnTime = System.currentTimeMillis();
        }

        // Detectar colisión con el protagonista
        if (isTouching(Protagonista.class)) {
            Counter contadorManzanas = (Counter) getWorld().getObjects(Counter.class).get(0);
            contadorManzanas.add(1);
            getWorld().removeObject(this);  // Eliminar la fresa
        }
    }

    private void spawnMazanaRandom() {
        int x = Greenfoot.getRandomNumber(700);
        int y = Greenfoot.getRandomNumber(650);
        getWorld().addObject(new Mazana(), x, y);
    }
}
